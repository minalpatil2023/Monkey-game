var monkey, player_running;
var obstacleImg,obstacleGroup;
var backgnd,backimg;
var bananaimg,foodGroup;
var score;
var ground;
function preload() {
  createCanvas(400, 400);
  backimg=loadImage("jungle.png");
 player_running =loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_03.pmg","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");
  
bananaImage=loadImage("Banana.png");
obstacle_img=loadImage("stone.png");
  
}
function setup(){
background=createSprite(200,200,20,20);
background.addImage(backimg);
background.velocityX=-5;
var ground = createSprite(400,350,800,10);
ground.visibility=false;
var monkey = createSprite(100, 340,20,50);
monkey.addImage( player_running);
  if(background.x<0) {
    background.x=background.width/2;
  }



}



function draw() {
  background(220);
  if(background.x<0) {
    background.x=background.width/2;
  }
  if(foodGroup.isTouching(monkey)){
  score=score+2;
  destroy(foodGroup);
  }
  
  switch(score){
    case 10:player.scale=0.12;
      break;
    case 20:player.scale=0.14;
      break;
    case 30:player.scale=0.16;
      break;
    case 40:player.scale=0.18;
      break;
    default: break;
  }
  if (obstacleGroup.isTouching(player)){
   player.scale=0.2; 
  }

drawSprites();
}
